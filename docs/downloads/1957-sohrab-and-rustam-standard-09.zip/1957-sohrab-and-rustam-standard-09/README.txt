GPURA CORPUS: SAMPLE PACKAGE
Sohrab and Rustam - Standard 09
Sohrab and Rustam - Standard 09 · A. Sankara Pillai · 1957

Source: https://gpura.org/item/1957-sohrab-and-rustam-standard-09
Pages in this package: 1 of 46 (viewer pages 10)
Packaged: 2026-11-04 · https://beniza.github.io/gpura-corpus

WHAT THIS IS
A structured, machine-readable companion to Gpura's scans of this item: for every page, the text
(what the page says), the structure (where it says it: regions, lines, reading order, positions on
the scan) and the metadata (what the item is). Region and line identifiers are the same in every file.

FILES
  item.json            catalogue metadata (from Gpura's Omeka S record)
  tei/<item>.tei.xml   TEI P5 edition: running text with headings, paragraphs, page breaks, page
                       numbers and running heads; every printed line points to its zone on the scan;
                       uncertain readings marked with <unclear> and their source
  page/pNNN.page.xml   PAGE-XML 2019 (master layout): regions, lines, baselines, reading order, and
                       each line's readings with their provenance and confidence
  alto/pNNN.alto.xml   ALTO 4.4, generated from PAGE-XML
  text/<item>.txt      plain text in reading order, one printed line per line, page markers
  images.txt           IIIF links to each page image at Gpura (coordinates in the XML refer to these)

WHERE THE TEXT COMES FROM
      18 lines  Sarvam Vision (Sarvam AI Document AI), where Gpura has no text
       7 lines  an AI model reading the line image (Claude)
Nothing in this package has been checked by a person unless marked "reviewed". Line boxes, regions and
reading order are detected automatically. All files validate against the official PAGE 2019, ALTO 4.4
and TEI P5 (tei_all) schemas.

LICENCE
The encoding is released under CC0 1.0 (see LICENSE.txt). The source item and its page images are in
the public domain per Gpura (gpura.org, Indic Digital Archive Foundation). This is an independent
proposal, not a Gpura publication.

FEEDBACK
This is a sample shared for comment. Please tell us what works, what is missing and what is wrong:
  https://github.com/beniza/gpura-corpus/issues/new?template=corpus-feedback.md
(or open an issue at https://github.com/beniza/gpura-corpus/issues). Useful: the file and line id
(e.g. p016_r02_l005), what you expected, and what you found.
